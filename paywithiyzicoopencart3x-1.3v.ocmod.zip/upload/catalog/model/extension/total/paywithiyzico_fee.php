<?php

class ModelExtensionTotalPaywithiyzicoFee extends Model{

    public function confirm($order_info, $order_total){
        
    }

}
